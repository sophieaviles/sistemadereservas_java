/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.ufg.modelo;


import javax.faces.bean.ManagedBean;

/**
 *
 * @author sofya
 */

@ManagedBean(name = "mdatostkn")


public class MdatosTkn {
    
    private int Id_tkn;
    private String Tkn;
    private String estado;

    public int getId_tkn() {
        return Id_tkn;
    }

    public void setId_tkn(int Id_tkn) {
        this.Id_tkn = Id_tkn;
    }

    public String getTkn() {
        return Tkn;
    }

    public void setTkn(String Tkn) {
        this.Tkn = Tkn;
    }

    
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    

}
