/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.ufg.Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import org.primefaces.context.RequestContext;
import sv.edu.ufg.Mysqlconector.Cconexion;

/**
 *
 * @author sofya
 */

@ManagedBean(name = "cgenerartkn")


public class CgenerarTkn {
    
    private int Id_tkn;
    private int Tkn;
    private String estado;
    
    
    FacesContext context = FacesContext.getCurrentInstance();

    public int getId_tkn() {
        return Id_tkn;
    }

    public void setId_tkn(int Id_tkn) {
        this.Id_tkn = Id_tkn;
    }

    public int getTkn() {
        return Tkn;
    }

    public void setTkn(int Tkn) {
        this.Tkn = Tkn;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
    
 
    public void Enviar_Tkn()
    {
    
    Connection cnn = Cconexion.conectar_ds();
    PreparedStatement psta;
    int result=0;
    
    try
    {
    psta = cnn.prepareStatement("INSERT INTO tocken (cod_tocken,estado) VALUES (?,?);");
    
    psta.setString(1, getTknNumber());
    psta.setString(2, getEstado());
    
    result = psta.executeUpdate();
    
    RequestContext.getCurrentInstance().update("growlTkn");
    FacesContext context = FacesContext.getCurrentInstance();
    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Token Generado es: ",String.valueOf(Tkn)));
    
    }
    
    catch(SQLException ex)
    {
    Logger.getLogger(CgenerarTkn.class.getName()).log(Level.SEVERE,null,ex);
        
    }

    
    }
 

    public String getTknNumber() {
        Random rnd = new Random();
        Tkn = rnd.nextInt((85636535 - 1) + 1);

        return String.valueOf(Tkn);
    }
    
}


