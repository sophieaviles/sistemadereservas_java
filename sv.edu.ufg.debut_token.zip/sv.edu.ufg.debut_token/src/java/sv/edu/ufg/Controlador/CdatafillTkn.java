/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.ufg.Controlador;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import sv.edu.ufg.Mysqlconector.Cconexion;
import sv.edu.ufg.modelo.MdatosTkn;

/**
 *
 * @author sofya
 */

@ManagedBean
@ViewScoped
public class CdatafillTkn implements Serializable {
    
    private List<MdatosTkn> datosT;

    public List<MdatosTkn> getDatosT() {
        return datosT;
    }

    public void setDatosT(List<MdatosTkn> datosT) {
        this.datosT = datosT;
    }
    
    @PostConstruct
    
    public void init() 
    {
        datosT= getDataT();
    }
    
    
    
    
    public List getDataT()
    {
    Connection cnn = Cconexion.conectar_ds();
        ResultSet rset = null;
        Statement sta;
        datosT = new ArrayList<>();
        try {
            sta = cnn.createStatement();
            rset = sta.executeQuery("SELECT\n"
                    + "    `tocken`.`id_tocken`\n"
                    + "    , `tocken`.`cod_tocken`\n"
                  
                    + "FROM\n"
                    + "    `dbbd`.`tocken`\n");
                   
            
            while (rset.next()) {
                MdatosTkn datosFilltkn = new MdatosTkn();
                datosFilltkn.setId_tkn(rset.getInt("id_tocken"));
                datosFilltkn.setTkn(rset.getString("cod_tocken"));
               

                datosT.add(datosFilltkn);
            }
            rset.close();
            sta.close();
            cnn.close();
            return datosT;
        } catch (SQLException ex) {
            
            Logger.getLogger(CdatafillTkn.class.getName()).log(Level.SEVERE,null,ex);
            
            return null;
        }
    }
    
}
