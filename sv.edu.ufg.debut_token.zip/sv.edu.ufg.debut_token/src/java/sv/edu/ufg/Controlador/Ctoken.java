/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.ufg.Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import org.primefaces.context.RequestContext;
import sv.edu.ufg.Mysqlconector.Cconexion;

/**
 *
 * @author sofya
 */

@ManagedBean(name = "ctoken")

public class Ctoken {
    
private String tAcceso;
  
   public void Val_tkn(String tkn)
   {
        Connection cnn = null;
        PreparedStatement psta=null;
        
        try {
            
            cnn = Cconexion.conectar_ds();
            psta = cnn.prepareStatement("SELECT estado FROM tocken WHERE cod_tocken= ? ");
            
            psta.setString(1, tkn);
      

            ResultSet rs= psta.executeQuery();
            
            if (rs.next()) // found
            {    
            tAcceso=rs.getString("estado");
               
                switch(tAcceso)
                {
                    case "activo":
                    
                    psta = cnn.prepareStatement("update tocken set estado='inactivo' where cod_tocken= ? ");
                    psta.setString(1, tkn);
                    
                    FacesContext.getCurrentInstance().getExternalContext().redirect("Vista_Registro.xhtml");
                    break;   
                    
                    case "inactivo":
                        
                    RequestContext.getCurrentInstance().update("growlTKN");
                    FacesContext context = FacesContext.getCurrentInstance();
                    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "TOKEN NO VÁLIDO", "¡INVALID CREDENTIALS!"));
                    
                    break;
                    
                }
               
          
            }
            else
            {
            RequestContext.getCurrentInstance().update("growlLogin");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "TOKEN NO VÁLIDO", "¡INVALID CREDENTIALS!"));
            
            }
            
        }
            catch (Exception e) {}
                 
       
    }
}
            
        
      
