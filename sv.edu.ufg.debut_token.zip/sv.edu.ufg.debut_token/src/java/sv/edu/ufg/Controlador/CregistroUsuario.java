/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.ufg.Controlador;

/**
 *
 * @author sofya
 */
import sv.edu.ufg.Mysqlconector.Cconexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.primefaces.context.RequestContext;
/**
 *
 * @author sofya
 */

@ManagedBean(name = "cregistro")
@SessionScoped
public class CregistroUsuario{
    
    private String Nombre;
    private String Apellido;
    private String Direccion;
    private String Telefono;
    private String usuario;
    private String clave;
    private int Id_rol;
    
    FacesContext context = FacesContext.getCurrentInstance();

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public int getId_rol() {
        return Id_rol;
    }

    public void setId_rol(int Id_rol) {
        this.Id_rol = Id_rol;
    }

    
    
    
 
    public void Enviar_Registro()
    {
    
    Connection cnn = Cconexion.conectar_ds();
    PreparedStatement psta;
    int result=0;

    try
    {   
        
    psta = cnn.prepareStatement("SELECT id_usuario FROM dbbd.usuario Where usuario=?");  
    psta.setString(1, usuario);
    ResultSet rs= psta.executeQuery();
    
    if (rs.next()) // found
            { 
            RequestContext.getCurrentInstance().update("growlRegistro");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Aviso", "¡Usuario ya existe!, elija otra combinacion."));
            }
    else
            {
             psta = cnn.prepareStatement("INSERT INTO usuario (nombre,apellido,direccion,telefono,usuario,contraseña,id_rol) VALUES (?,?,?,?,?,?,?);");
    
                psta.setString(1, getNombre());
                psta.setString(2, getApellido());
                psta.setString(3, getDireccion());
                psta.setString(4, getTelefono());
                psta.setString(5, getUsuario());
                psta.setString(6, getClave());
                psta.setInt   (7, getId_rol());
    
    
                result = psta.executeUpdate();
    
                RequestContext.getCurrentInstance().update("growlRegistro");
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "AVISO!", "REGISTRO GUARDADO CON EXITO!"));
            }
    
    }
    
    catch(SQLException ex)
    {
    Logger.getLogger(CregistroUsuario.class.getName()).log(Level.SEVERE,null,ex);
        
    }
    
    
    
    }
    
    
}

